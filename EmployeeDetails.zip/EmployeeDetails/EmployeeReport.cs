﻿using EmployeeDetails.ViewModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmployeeDetails
{
    public partial class EmployeeReport : Form
    {
        public List<EmployeeViewModel> _list;

        public EmployeeReport(List<EmployeeViewModel> lisy)
        {
            this._list = lisy;
        }

        private void EmployeeReport_Load(object sender, EventArgs e)
        {
            CrystalReport1 rpt = new CrystalReport1();
            rpt.SetDataSource(_list);
            crystalReportViewer1.ReportSource = rpt;
            crystalReportViewer1.Refresh();

        }
    }
}
